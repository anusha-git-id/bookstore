package com.simplebookstore.simplebookstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimplebookstoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimplebookstoreApplication.class, args);
	}

}
