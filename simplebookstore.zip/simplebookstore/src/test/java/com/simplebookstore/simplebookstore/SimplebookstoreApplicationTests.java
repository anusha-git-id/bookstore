package com.simplebookstore.simplebookstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimplebookstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
